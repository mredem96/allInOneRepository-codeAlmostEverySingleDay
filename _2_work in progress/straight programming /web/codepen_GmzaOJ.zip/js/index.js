'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/*------------------------------*\
|* Main Canvas
\*------------------------------*/

var Canvas = function () {
    function Canvas() {
        _classCallCheck(this, Canvas);

        // setup a canvas
        this.canvas = document.getElementById('canvas');
        this.dpr = window.devicePixelRatio || 1;
        // this.dpr = 1;

        this.radius = 6 * this.dpr;
        this.spread = this.radius / 3;

        this.ctx = this.canvas.getContext('2d');
        this.ctx.scale(this.dpr, this.dpr);

        this.mouse = {
            x: 0,
            y: 0
        };

        this.setCanvasSize = this.setCanvasSize.bind(this);
        this.handleClick = this.handleClick.bind(this);
        this.handleMouse = this.handleMouse.bind(this);
        this.render = this.render.bind(this);

        this.setCanvasSize();
        this.setupListeners();

        this.constructLines();

        this.tick = 0;
        this.render();
    }

    Canvas.prototype.constructLines = function constructLines() {
        var _this = this;

        var padding = 60 * this.dpr;
        var dy = (this.canvas.height - padding * 2) / this.radius / this.spread;
        var amount = Math.ceil(dy);
        // console.log(amount);
        this.lines = new Array(amount).fill(null).map(function (l, i) {
            var p1 = new Point(padding, padding + i * _this.radius * _this.spread);

            var p2 = new Point(_this.canvas.width - padding, padding + i * _this.radius * _this.spread);

            return new Line(Math.floor(_this.canvas.width / _this.radius / _this.spread), p1, p2);
        });
    };

    Canvas.prototype.updateVerts = function updateVerts() {
        var _this2 = this;

        this.lines.map(function (line, i) {
            var l = line.vertices.length;
            var r = 1 / l;
            line.vertices.map(function (p, i) {
                return p.moveTo(p.x, p.y + Math.cos(_this2.tick / 10 + i));
            });
        });
    };

    Canvas.prototype.setupListeners = function setupListeners() {
        window.addEventListener('resize', this.setCanvasSize);
        window.addEventListener('click', this.handleClick);
        window.addEventListener('mousemove', this.handleMouse);
    };

    Canvas.prototype.handleClick = function handleClick(event) {
        var _event$clientX = event.clientX;
        var x = _event$clientX.x;
        var y = _event$clientX.y;
    };

    Canvas.prototype.handleMouse = function handleMouse(event) {
        var x = event.clientX * this.dpr;
        var y = event.clientY * this.dpr;
        this.mouse = { x: x, y: y };
    };

    Canvas.prototype.setCanvasSize = function setCanvasSize() {
        this.canvas.width = window.innerWidth * this.dpr;
        this.canvas.height = window.innerHeight * this.dpr;
        this.canvas.style.width = window.innerWidth + 'px';
        this.canvas.style.height = window.innerHeight + 'px';

        this.constructLines();
    };

    Canvas.prototype.drawBackground = function drawBackground() {
        var gradient = this.ctx.createLinearGradient(0, 0, this.canvas.width, this.canvas.height);
        gradient.addColorStop(0, 'black');
        gradient.addColorStop(1, 'grey');
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    };

    Canvas.prototype.drawText = function drawText() {
        var size = this.canvas.width / 20;
        this.ctx.font = 'bold ' + size + 'px Futura';
        this.ctx.textAlign = 'center';
        this.ctx.fillStyle = 'white';
        this.ctx.fillText('Tiago Morais Morgado', this.canvas.width / 2, this.canvas.height / 2 + size / 2);
    };

    Canvas.prototype.drawLine = function drawLine() {
        this.ctx.beginPath();
        this.ctx.strokeStyle = 'white';
        this.ctx.lineWidth = 2 * this.dpr;
        this.ctx.moveTo(this.line.p1.x, this.line.p1.y);
        this.ctx.lineTo(this.line.p2.x, this.line.p2.y);
        this.ctx.stroke();
    };

    Canvas.prototype.drawVerts = function drawVerts() {
        var _this3 = this;

        this.lines.forEach(function (line) {
            _this3.ctx.lineWidth = 1 * _this3.dpr;
            _this3.ctx.strokeStyle = '#87cefa';

            line.vertices.forEach(function (p) {
                _this3.ctx.beginPath();
                _this3.ctx.arc(p.x, p.y, _this3.radius, 0, Math.PI * 2, true);
                _this3.ctx.closePath();
                _this3.ctx.stroke();
            });
        });
    };

    Canvas.prototype.render = function render() {
        this.drawBackground();
        this.drawVerts();
        this.updateVerts();
        this.drawText();

        this.tick++;
        window.requestAnimationFrame(this.render);
    };

    return Canvas;
}();

var Line = function Line(vertices, p1, p2) {
    _classCallCheck(this, Line);

    this.p1 = p1;
    this.p2 = p2;

    var dx = p2.x - p1.x;
    var dy = p2.y - p1.y;

    var vx = dx / (vertices - 1);
    var vy = dy / (vertices - 1);

    this.vertices = new Array(vertices).fill(null).map(function (p, i) {
        return new Point(p1.x + vx * i, p1.y + vy * i);
    });
};

var Point = function () {
    function Point() {
        var x = arguments.length <= 0 || arguments[0] === undefined ? 0 : arguments[0];
        var y = arguments.length <= 1 || arguments[1] === undefined ? 0 : arguments[1];

        _classCallCheck(this, Point);

        this.x = x;
        this.y = y;
    }

    Point.prototype.moveTo = function moveTo() {
        this.x = arguments.length <= 0 ? undefined : arguments[0];
        this.y = arguments.length <= 1 ? undefined : arguments[1];
    };

    _createClass(Point, [{
        key: 'position',
        get: function get() {
            return {
                x: this.x,
                y: this.y
            };
        }
    }]);

    return Point;
}();

new Canvas();