A Pen created at CodePen.io. You can find this one at http://codepen.io/tiagomoraismorgado/pen/VbgONY.

 Math from:<br>
math.stackexchange: <a href="https://math.stackexchange.com/questions/1585975/how-to-generate-random-points-on-a-sphere#1586185">How to generate random points on a sphere</a>.
