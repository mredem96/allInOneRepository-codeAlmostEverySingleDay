A Pen created at CodePen.io. You can find this one at http://codepen.io/tiagomoraismorgado/pen/mmvZWW.

 ### Here a simple ripple effect in vanilla js, ready to use for your project !
works in mobile too ;)