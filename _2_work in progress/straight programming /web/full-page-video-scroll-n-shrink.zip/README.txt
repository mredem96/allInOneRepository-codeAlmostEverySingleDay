A Pen created at CodePen.io. You can find this one at http://codepen.io/tiagomoraismorgado/pen/qmzZVP.

 Video from: https://www.videvo.net/video/blurry-trees-background-loop-2/3505/

Really good reference: http://thenewcode.com/777/Create-Fullscreen-HTML5-Page-Background-Video